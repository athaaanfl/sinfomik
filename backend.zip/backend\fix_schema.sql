-- Remove password_hash column from Siswa table
ALTER TABLE Siswa DROP COLUMN password_hash;
